# Flask Video Streaming Server

A Python Flask server that uses Jinja2 templates to display and stream videos using HTML5's video plugin.

## Features

- 🎬 HTML5 video player with full controls
- 🔄 Support for multiple video formats (MP4, WebM, Ogg)
- 📱 Responsive design that works on all devices
- 🎨 Modern, gradient UI with smooth animations
- ⏭️ Playlist functionality with auto-play next video
- 🎯 Easy video switching with visual feedback

## Requirements

- Python 3.7+
- Flask
- Jinja2

## Installation

1. Clone this repository:
```bash
git clone https://github.com/gauravphadke/aks-experiment-1.git
cd aks-experiment-1
```

2. Install dependencies:
```bash
pip install -r requirements.txt
```

3. Add your video files:
   - Place your video files (.mp4, .webm, or .ogg) in the `static/videos` directory
   - The directory is created automatically when you run the application

## Usage

1. Start the Flask server:
```bash
python app.py
```

2. Open your browser and navigate to:
```
http://localhost:5000
```

3. The video player will automatically load and display available videos.

## Project Structure

```
flask-video-app/
├── app.py                 # Main Flask application
├── requirements.txt       # Python dependencies
├── templates/
│   └── index.html        # Jinja2 template for video player
└── static/
    └── videos/           # Directory for video files
```

## How It Works

### Flask Server (`app.py`)
- **Main Route (`/`)**: Renders the video player page using Jinja2 template
- **Video Route (`/video/<filename>`)**: Serves video files with proper MIME types
- **Stream Route (`/stream/<filename>`)**: Provides advanced streaming with range request support for seeking

### Jinja2 Template (`index.html`)
- Uses Jinja2 templating to dynamically generate the video list
- Implements HTML5 `<video>` element with full controls
- Includes JavaScript for playlist functionality
- Responsive CSS design with gradient backgrounds

## Features Explained

### HTML5 Video Controls
The video player includes:
- Play/Pause button
- Progress bar with seeking
- Volume control
- Fullscreen toggle
- Time display

### Playlist Functionality
- Automatically detects all videos in `static/videos` directory
- Click any video in the list to play it
- Videos auto-advance to the next one when finished
- Visual indication of currently playing video

### Supported Video Formats
- **MP4** (H.264): Best compatibility
- **WebM**: Modern, efficient format
- **Ogg**: Open-source alternative

## Customization

### Changing the Port
Edit `app.py` and modify the last line:
```python
app.run(debug=True, host='0.0.0.0', port=5000)  # Change port here
```

### Styling
Modify the `<style>` section in `templates/index.html` to customize:
- Colors and gradients
- Layout and spacing
- Animations and transitions

### Adding Features
Extend `app.py` to add:
- Video upload functionality
- User authentication
- Video metadata display
- Subtitle support

## Deployment

### Local Development
```bash
python app.py
```

### Production (using Gunicorn)
```bash
pip install gunicorn
gunicorn -w 4 -b 0.0.0.0:5000 app:app
```

### Docker
Create a `Dockerfile`:
```dockerfile
FROM python:3.9-slim
WORKDIR /app
COPY requirements.txt .
RUN pip install -r requirements.txt
COPY . .
EXPOSE 5000
CMD ["python", "app.py"]
```

Build and run:
```bash
docker build -t flask-video-app .
docker run -p 5000:5000 flask-video-app
```

## Troubleshooting

### Videos Not Playing
- Ensure video files are in `static/videos` directory
- Check file formats are supported (.mp4, .webm, .ogg)
- Verify file permissions allow reading

### Port Already in Use
- Change the port in `app.py`
- Or stop the process using port 5000

### Module Not Found Error
- Run `pip install -r requirements.txt`
- Activate your virtual environment if using one

## License

MIT License - Feel free to use and modify as needed.

## Contributing

Pull requests are welcome! For major changes, please open an issue first to discuss what you would like to change.

from flask import Flask, render_template, Response, send_file, request
import os

app = Flask(__name__)

# Configure upload folder for videos
UPLOAD_FOLDER = 'static/videos'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/')
def index():
    """
    Main route that renders the video player page
    """
    # Get list of available videos
    videos = []
    if os.path.exists(UPLOAD_FOLDER):
        videos = [f for f in os.listdir(UPLOAD_FOLDER) if f.endswith(('.mp4', '.webm', '.ogg'))]
    
    return render_template('index.html', videos=videos)

@app.route('/video/<filename>')
def video(filename):
    """
    Route to serve video files with proper streaming support
    """
    video_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    if not os.path.exists(video_path):
        return "Video not found", 404
    
    return send_file(video_path, mimetype='video/mp4')

@app.route('/stream/<filename>')
def stream_video(filename):
    """
    Advanced streaming route with range request support for seeking
    """
    video_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    
    if not os.path.exists(video_path):
        return "Video not found", 404
    
    # Get file size
    file_size = os.path.getsize(video_path)
    
    # Parse range header
    range_header = request.headers.get('Range', None)
    
    if not range_header:
        # No range requested, send entire file
        return send_file(video_path, mimetype='video/mp4')
    
    # Parse range header
    byte_range = range_header.replace('bytes=', '').split('-')
    start = int(byte_range[0]) if byte_range[0] else 0
    end = int(byte_range[1]) if byte_range[1] else file_size - 1
    
    # Ensure valid range
    if start >= file_size or end >= file_size:
        return "Invalid range", 416
    
    length = end - start + 1
    
    # Read the chunk
    with open(video_path, 'rb') as video_file:
        video_file.seek(start)
        data = video_file.read(length)
    
    # Create response with partial content
    response = Response(data, 206, mimetype='video/mp4')
    response.headers.add('Content-Range', f'bytes {start}-{end}/{file_size}')
    response.headers.add('Accept-Ranges', 'bytes')
    response.headers.add('Content-Length', str(length))
    
    return response

if __name__ == '__main__':
    app.run(debug=True, host='0.0.0.0', port=5000)
